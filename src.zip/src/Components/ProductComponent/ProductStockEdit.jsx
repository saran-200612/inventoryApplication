import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from "react-router-dom";
import { getProductById, editProductStock } from '../../Services/ProductService';
import { getUserId } from '../../Services/LoginService';
import { transactionIdGenerate, saveTransaction } from '../../Services/TransactionService';

const ProductStockEdit = () => {

    const [product, setProduct] = useState({
        productId: "",
        productName: "",
        skuId: "",
        purchasePrice: 0.0,
        salesPrice: 0.0,
        reorderLevel: 0.0,
        stock: 0.0,
        vendorId: "",
        status: true,
    });

    const [newId, setNewId] = useState(0);
    const [errors, setErrors] = useState({});
    const [flag, setFlag] = useState("");
    const [userId, setUserId] = useState("");
    const [tdate, setTdate] = useState(new Date().toISOString().split('T')[0]);

    const [transaction, setTransaction] = useState({
        transactionId: 0,
        transactionType: "",
        productId: "",
        rate: 0.0,
        quantity: 0.0,
        transactionValue: 0.0,
        userId: "",
        transactionDate: "",
    });

    const navigate = useNavigate();
    const param = useParams();

    const [quantity, setQuantity] = useState(0.0);
    const [transValue, setTransValue] = useState(null);
    const [warns, setWarns] = useState(null);

    const setProductData = () => {
        getProductById(param.pid).then(response => {
            setProduct(response.data);
            setFlag(param.no);
        });
    };

    const setUserData = () => {
        getUserId().then(response => {
            setUserId(response.data);
        });
    };

    const setTransactionId = () => {
        transactionIdGenerate(param.no).then(response => {
            setNewId(response.data);
        }).catch(err => {
            console.error("Transaction ID fetch failed:", err);
        });
    };

    useEffect(() => {
        setProductData();
        setUserData();
        setTransactionId();
    }, []);

    const returnBack = () => {
        navigate('/product-repo');
    };

    const clearAll = () => {
        setQuantity(0.0);
    };

    const stockEdit = (event) => {
        event.preventDefault();

        const updatedTransaction = {
            ...transaction,
            transactionId: newId,
            productId: product.productId,
            quantity: quantity,
            userId: userId,
            transactionDate: tdate,
            transactionType: flag === "1" ? "IN" : "OUT",
            rate: flag === "1" ? product.purchasePrice : product.salesPrice,
        };

        updatedTransaction.transactionValue =
            parseFloat(updatedTransaction.rate) * parseFloat(quantity);

        setTransValue(updatedTransaction.transactionValue);

        if (flag === "2") {
            let balance = product.stock - quantity;
            if (balance <= product.reorderLevel)
                setWarns("Stock reached to Re-Order Level.....");
        }

        saveTransaction(updatedTransaction).catch(err => console.error("Save transaction failed:", err));
        editProductStock(product, quantity, flag).catch(err => console.error("Edit stock failed:", err));
    };

    const handleValidation = (event) => {
        event.preventDefault();
        let tempErrors = {};
        let isValid = true;

        if (!String(quantity).trim()) {
            tempErrors.quantity = "Transaction Quantity is required";
            isValid = false;
        } else if (parseFloat(quantity) <= 0) {
            tempErrors.quantity = "Transaction Quantity cannot be 0 or negative";
            isValid = false;
        }

        if (flag === "2") {
            if (parseFloat(quantity) > product.stock) {
                tempErrors.quantity = "Issued Quantity cannot be more than stock";
                isValid = false;
            }
        }

        setErrors(tempErrors);
        if (isValid) {
            stockEdit(event);
        }
    };

    return (
        <div className="container mt-4">
            <div className="row justify-content-center">
                <div className="col-md-8">

                    {/* Title */}
                    <div className="text-center mb-3">
                        {parseInt(flag) === 1
                            ? <h3><u>Stock Purchase Entry</u></h3>
                            : <h3><u>Stock Issue Entry</u></h3>
                        }
                    </div>

                    {/* Product Details Card */}
                    <div className="card mb-3">
                        <div className="card-header">
                            <b>Product Details</b>
                        </div>
                        <div className="card-body p-0">
                            <table className="table table-bordered mb-0">
                                <tbody>
                                    <tr>
                                        <td width="40%"><b>Product Id</b></td>
                                        <td>{product.productId}</td>
                                    </tr>
                                    <tr>
                                        <td><b>SKU Id</b></td>
                                        <td>{product.skuId}</td>
                                    </tr>
                                    <tr>
                                        <td><b>Product Name</b></td>
                                        <td>{product.productName}</td>
                                    </tr>
                                    <tr>
                                        <td><b>{parseInt(flag) === 1 ? "Purchase Price" : "Sales Price"}</b></td>
                                        <td>₹{parseInt(flag) === 1 ? product.purchasePrice : product.salesPrice}</td>
                                    </tr>
                                    <tr>
                                        <td><b>Re Order Level</b></td>
                                        <td>{product.reorderLevel}</td>
                                    </tr>
                                    <tr>
                                        <td><b>Stock</b></td>
                                        <td>{product.stock}</td>
                                    </tr>
                                    <tr>
                                        <td><b>Vendor</b></td>
                                        <td>{product.vendorId}</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>

                    {/* Transaction Entry Card */}
                    <div className="card">
                        <div className="card-header">
                            <b>Transaction Entry</b>
                        </div>
                        <div className="card-body">
                            <form>
                                <div className="form-group mb-3">
                                    <label><b>Transaction Id</b></label>
                                    <input
                                        className="form-control"
                                        value={newId}
                                        readOnly
                                    />
                                </div>

                                <div className="form-group mb-3">
                                    <label><b>Transaction Date</b></label>
                                    <input
                                        type="date"
                                        className="form-control"
                                        value={tdate}
                                        onChange={(event) => setTdate(event.target.value)}
                                    />
                                </div>

                                <div className="form-group mb-3">
                                    <label><b>Quantity</b></label>
                                    <input
                                        className="form-control"
                                        value={quantity}
                                        onChange={(event) => setQuantity(event.target.value)}
                                    />
                                    {errors.quantity && (
                                        <p style={{ color: "red" }}>{errors.quantity}</p>
                                    )}
                                </div>

                                <div className="d-flex gap-2">
                                    <button
                                        className="btn btn-success"
                                        onClick={handleValidation}
                                    >
                                        Save
                                    </button>
                                    <button
                                        className="btn btn-secondary"
                                        type="button"
                                        onClick={clearAll}
                                    >
                                        Reset
                                    </button>
                                    <button
                                        className="btn btn-warning"
                                        type="button"
                                        onClick={returnBack}
                                    >
                                        Return
                                    </button>
                                </div>
                            </form>

                            {transValue !== null && (
                                <div className="alert alert-success mt-3">
                                    <b>Transaction Value: ₹{transValue}</b>
                                </div>
                            )}
                            {warns && (
                                <div className="alert alert-danger mt-2">
                                    {warns}
                                </div>
                            )}
                        </div>
                    </div>

                </div>
            </div>
        </div>
    );
};

export default ProductStockEdit;