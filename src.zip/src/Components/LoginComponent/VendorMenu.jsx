import React, { useState, useEffect } from "react";
import { useNavigate } from 'react-router-dom';
import { logoutUser, getUserId } from '../../Services/LoginService';
import { getProductByVendor } from '../../Services/ProductService';

const VendorMenu = () => {

    let navigate = useNavigate();
    const [products, setProducts] = useState([]);
    const [vendorId, setVendorId] = useState("");
    const [loading, setLoading] = useState(true);
    const [selectedProduct, setSelectedProduct] = useState(null);
    const [requestedQty, setRequestedQty] = useState("");
    const [requestDate, setRequestDate] = useState(new Date().toISOString().split('T')[0]);
    const [successMsg, setSuccessMsg] = useState("");
    const [errors, setErrors] = useState({});
    const [requests, setRequests] = useState([]);

    useEffect(() => {
        getUserId().then(res => {
            const vid = res.data;
            setVendorId(vid);
            getProductByVendor(vid).then(r => {
                setProducts(r.data);
                setLoading(false);
            }).catch(() => setLoading(false));
        }).catch(() => {
            sessionStorage.clear();
            navigate('/');
        });
    }, []);

    const handleLogout = () => {
        logoutUser().then(() => {
            localStorage.clear();
            sessionStorage.clear();
            navigate('/');
        });
    };

    const openRequest = (product) => {
        setSelectedProduct(product);
        setRequestedQty("");
        setSuccessMsg("");
        setErrors({});
    };

    const closeRequest = () => {
        setSelectedProduct(null);
        setErrors({});
        setSuccessMsg("");
    };

    const submitRequest = () => {
        if (!requestedQty || parseFloat(requestedQty) <= 0) {
            setErrors({ qty: "Please enter a valid quantity" });
            return;
        }

        const request = {
            requestId: "REQ" + Date.now(),
            productId: selectedProduct.productId,
            vendorId: vendorId,
            requestedQty: parseFloat(requestedQty),
            status: "PENDING",
            requestDate: requestDate
        };

        setRequests(prev => [...prev, request]);
        setSuccessMsg("Request submitted successfully!");
        setRequestedQty("");
        setErrors({});
    };

    return (
        <>
            <style>{`
                @import url('https://fonts.googleapis.com/css2?family=Rajdhani:wght@400;500;600;700&family=Share+Tech+Mono&display=swap');
                .vm-root {
                    min-height:100vh; width:100%; font-family:'Rajdhani',sans-serif;
                    background-color:#0a0e1a;
                    background-image:
                        radial-gradient(ellipse at 20% 50%,rgba(14,165,233,0.06) 0%,transparent 60%),
                        url('https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?auto=format&fit=crop&w=1920&q=60');
                    background-size:cover; background-position:center;
                    background-attachment:fixed; position:relative;
                }
                .vm-root::before {
                    content:''; position:fixed; inset:0;
                    background:linear-gradient(135deg,rgba(5,10,25,0.82) 0%,rgba(8,15,35,0.75) 50%,rgba(5,10,25,0.85) 100%);
                    z-index:0;
                }
                .vm-content { position:relative; z-index:1; }
                .vm-header {
                    background:rgba(14,165,233,0.08); backdrop-filter:blur(20px);
                    border-bottom:1px solid rgba(14,165,233,0.2);
                    padding:16px 32px; display:flex; align-items:center; justify-content:space-between;
                }
                .vm-title { font-size:22px; font-weight:700; color:#e0f2fe; letter-spacing:1.5px; text-transform:uppercase; }
                .vm-subtitle { font-size:11px; color:rgba(14,165,233,0.7); letter-spacing:2px; text-transform:uppercase; }
                .vm-logout {
                    background:rgba(248,113,113,0.15); border:1px solid rgba(248,113,113,0.4);
                    color:#f87171; padding:9px 20px; border-radius:8px;
                    font-family:'Rajdhani',sans-serif; font-size:14px; font-weight:600;
                    cursor:pointer; transition:all 0.2s;
                }
                .vm-logout:hover { background:rgba(248,113,113,0.28); color:#fca5a5; }
                .vm-body { padding:24px 32px; }
                .vm-section-title {
                    font-size:13px; font-weight:600; letter-spacing:2px;
                    text-transform:uppercase; color:rgba(14,165,233,0.7); margin-bottom:14px;
                }
                .vm-table-glass {
                    background:rgba(10,20,45,0.55); backdrop-filter:blur(24px);
                    border:1px solid rgba(14,165,233,0.15); border-radius:16px; overflow:hidden;
                    box-shadow:0 24px 48px rgba(0,0,0,0.4); margin-bottom:32px;
                }
                .vm-table { width:100%; border-collapse:collapse; font-family:'Rajdhani',sans-serif; }
                .vm-table thead tr { background:rgba(14,165,233,0.1); border-bottom:1px solid rgba(14,165,233,0.2); }
                .vm-table thead th {
                    padding:14px 16px; text-align:left; font-size:11px; font-weight:600;
                    letter-spacing:2px; text-transform:uppercase; color:rgba(14,165,233,0.8);
                }
                .vm-table tbody tr { border-bottom:1px solid rgba(255,255,255,0.04); transition:background 0.15s; }
                .vm-table tbody tr:hover { background:rgba(14,165,233,0.06); }
                .vm-table tbody tr:last-child { border-bottom:none; }
                .vm-table td { padding:13px 16px; font-size:14px; color:#cbd5e1; vertical-align:middle; }
                .mono { font-family:'Share Tech Mono',monospace; font-size:12px; color:#7dd3fc; }
                .price { font-family:'Share Tech Mono',monospace; font-size:13px; color:#e2e8f0; }
                .badge-ok { background:rgba(52,211,153,0.12); border:1px solid rgba(52,211,153,0.3); color:#34d399; padding:3px 9px; border-radius:20px; font-size:11px; font-weight:600; }
                .badge-warn { background:rgba(248,113,113,0.12); border:1px solid rgba(248,113,113,0.3); color:#f87171; padding:3px 9px; border-radius:20px; font-size:11px; font-weight:600; }
                .badge-pending { background:rgba(251,191,36,0.12); border:1px solid rgba(251,191,36,0.3); color:#fbbf24; padding:3px 9px; border-radius:20px; font-size:11px; font-weight:600; }
                .btn-request {
                    background:rgba(14,165,233,0.15); border:1px solid rgba(14,165,233,0.4);
                    color:#7dd3fc; padding:5px 14px; border-radius:6px;
                    font-family:'Rajdhani',sans-serif; font-size:12px; font-weight:600;
                    cursor:pointer; transition:all 0.2s;
                }
                .btn-request:hover { background:rgba(14,165,233,0.28); color:#e0f2fe; }
                .vm-empty { padding:30px; text-align:center; color:rgba(148,163,184,0.5); font-size:14px; }
                .vm-loader { display:flex; align-items:center; justify-content:center; gap:8px; padding:60px; color:rgba(14,165,233,0.6); font-size:14px; letter-spacing:2px; }
                .spinner { width:18px; height:18px; border:2px solid rgba(14,165,233,0.2); border-top-color:#0ea5e9; border-radius:50%; animation:spin 0.8s linear infinite; }
                @keyframes spin { to { transform:rotate(360deg); } }
                .vm-modal-overlay { position:fixed; inset:0; background:rgba(0,0,0,0.7); backdrop-filter:blur(4px); z-index:100; display:flex; align-items:center; justify-content:center; }
                .vm-modal { background:#0d1b2e; border:1px solid rgba(14,165,233,0.3); border-radius:16px; padding:32px; width:100%; max-width:440px; box-shadow:0 24px 48px rgba(0,0,0,0.6); }
                .vm-modal-title { font-size:18px; font-weight:700; color:#e0f2fe; letter-spacing:1px; text-transform:uppercase; margin-bottom:20px; }
                .vm-modal-row { display:flex; justify-content:space-between; padding:8px 0; border-bottom:1px solid rgba(255,255,255,0.05); font-size:14px; }
                .vm-modal-row:last-of-type { border-bottom:none; }
                .vm-modal-key { color:rgba(14,165,233,0.7); font-weight:600; }
                .vm-modal-val { color:#e2e8f0; font-family:'Share Tech Mono',monospace; font-size:13px; }
                .vm-modal-divider { border:none; border-top:1px solid rgba(14,165,233,0.15); margin:18px 0; }
                .vm-modal-label { display:block; font-size:12px; font-weight:600; letter-spacing:1.5px; text-transform:uppercase; color:rgba(14,165,233,0.7); margin-bottom:6px; }
                .vm-modal-input { width:100%; padding:10px 14px; background:rgba(255,255,255,0.05); border:1px solid rgba(14,165,233,0.2); border-radius:8px; color:#e2e8f0; font-family:'Rajdhani',sans-serif; font-size:14px; outline:none; box-sizing:border-box; transition:border-color 0.2s; }
                .vm-modal-input:focus { border-color:rgba(14,165,233,0.5); }
                .vm-modal-actions { display:flex; gap:10px; margin-top:20px; }
                .vm-modal-submit { flex:1; padding:11px; background:linear-gradient(135deg,#0ea5e9,#0284c7); border:none; border-radius:8px; color:#fff; font-family:'Rajdhani',sans-serif; font-size:14px; font-weight:700; cursor:pointer; transition:all 0.2s; }
                .vm-modal-submit:hover { background:linear-gradient(135deg,#38bdf8,#0ea5e9); }
                .vm-modal-cancel { flex:1; padding:11px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); border-radius:8px; color:#94a3b8; font-family:'Rajdhani',sans-serif; font-size:14px; font-weight:600; cursor:pointer; }
                .vm-success { background:rgba(52,211,153,0.12); border:1px solid rgba(52,211,153,0.3); border-radius:8px; padding:10px; text-align:center; color:#34d399; font-weight:600; margin-top:14px; }
                .vm-error { color:#f87171; font-size:12px; margin-top:4px; }
            `}</style>

            <div className="vm-root">
                <div className="vm-content">

                    <div className="vm-header">
                        <div>
                            <div className="vm-title">🏪 Vendor Dashboard</div>
                            <div className="vm-subtitle">{vendorId} · My Products</div>
                        </div>
                        <button className="vm-logout" onClick={handleLogout}>Logout</button>
                    </div>

                    <div className="vm-body">

                        <div className="vm-section-title">📦 My Products — Click Request to raise a stock request</div>
                        <div className="vm-table-glass">
                            {loading ? (
                                <div className="vm-loader"><div className="spinner"></div>LOADING...</div>
                            ) : products.length === 0 ? (
                                <div className="vm-empty">No products assigned to your account.</div>
                            ) : (
                                <table className="vm-table">
                                    <thead>
                                        <tr>
                                            <th>Product ID</th>
                                            <th>SKU</th>
                                            <th>Name</th>
                                            <th>Sale Price</th>
                                            <th>Stock</th>
                                            <th>Status</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {products.map(p => (
                                            <tr key={p.productId}>
                                                <td><span className="mono">{p.productId}</span></td>
                                                <td><span className="mono">{p.skuId}</span></td>
                                                <td style={{fontWeight:600,color:'#e2e8f0'}}>{p.productName}</td>
                                                <td><span className="price">₹{p.salesPrice}</span></td>
                                                <td style={{color:p.status?'#34d399':'#f87171',fontWeight:700}}>{p.stock}</td>
                                                <td>
                                                    {p.status
                                                        ? <span className="badge-ok">✓ Available</span>
                                                        : <span className="badge-warn">⚠ Low Stock</span>}
                                                </td>
                                                <td>
                                                    <button className="btn-request" onClick={() => openRequest(p)}>
                                                        📋 Request
                                                    </button>
                                                </td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            )}
                        </div>

                        <div className="vm-section-title">📋 My Stock Requests (This Session)</div>
                        <div className="vm-table-glass">
                            {requests.length === 0 ? (
                                <div className="vm-empty">No requests raised yet.</div>
                            ) : (
                                <table className="vm-table">
                                    <thead>
                                        <tr>
                                            <th>Product ID</th>
                                            <th>Qty Requested</th>
                                            <th>Date</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {requests.map((r, i) => (
                                            <tr key={i}>
                                                <td><span className="mono">{r.productId}</span></td>
                                                <td>{r.requestedQty}</td>
                                                <td style={{color:'#94a3b8'}}>{r.requestDate}</td>
                                                <td><span className="badge-pending">⏳ Pending</span></td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            )}
                        </div>

                    </div>
                </div>
            </div>

            {/* Request Modal */}
            {selectedProduct && (
                <div className="vm-modal-overlay">
                    <div className="vm-modal">
                        <div className="vm-modal-title">📋 Raise Stock Request</div>

                        <div className="vm-modal-row">
                            <span className="vm-modal-key">Product ID</span>
                            <span className="vm-modal-val">{selectedProduct.productId}</span>
                        </div>
                        <div className="vm-modal-row">
                            <span className="vm-modal-key">Product Name</span>
                            <span className="vm-modal-val">{selectedProduct.productName}</span>
                        </div>
                        <div className="vm-modal-row">
                            <span className="vm-modal-key">Current Stock</span>
                            <span className="vm-modal-val">{selectedProduct.stock}</span>
                        </div>
                        <div className="vm-modal-row">
                            <span className="vm-modal-key">Sales Price</span>
                            <span className="vm-modal-val">₹{selectedProduct.salesPrice}</span>
                        </div>

                        <hr className="vm-modal-divider" />

                        <div style={{marginBottom:'14px'}}>
                            <label className="vm-modal-label">Request Date</label>
                            <input
                                type="date"
                                className="vm-modal-input"
                                value={requestDate}
                                onChange={e => setRequestDate(e.target.value)}
                            />
                        </div>

                        <div>
                            <label className="vm-modal-label">Quantity to Request</label>
                            <input
                                type="number"
                                className="vm-modal-input"
                                placeholder="Enter quantity"
                                value={requestedQty}
                                onChange={e => { setRequestedQty(e.target.value); setErrors({}); }}
                            />
                            {errors.qty && <div className="vm-error">{errors.qty}</div>}
                        </div>

                        {successMsg && <div className="vm-success">✅ {successMsg}</div>}

                        <div className="vm-modal-actions">
                            <button className="vm-modal-submit" onClick={submitRequest}>
                                Submit Request
                            </button>
                            <button className="vm-modal-cancel" onClick={closeRequest}>
                                Cancel
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </>
    );
};

export default VendorMenu;