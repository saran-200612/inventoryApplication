import React, { useState } from "react";
import { useNavigate } from 'react-router-dom';
import { logoutUser } from '../../Services/LoginService';

const ManagerMenu = () => {
    let navigate = useNavigate();
    const [openSKU, setOpenSKU] = useState(false);
    const [openProduct, setOpenProduct] = useState(false);
    const [openTrans, setOpenTrans] = useState(false);

    const handleLogout = () => {
        logoutUser().then(() => {
            localStorage.clear();
            sessionStorage.clear();
            navigate('/');
        });
    };

    const go = (path) => {
        navigate(path);
    };

    return (
        <div>
            <br />
            <div align="center" style={{ backgroundColor: 'pink' }}>
                <h1 className="text-center" style={{ color: 'magenta' }}>
                    <u><i>Inventory Manager Menu</i></u>
                </h1>
            </div>

            {/* Navbar */}
            <div style={{
                backgroundColor: '#ffc107',
                padding: '8px 16px',
                display: 'flex',
                alignItems: 'center',
                gap: '4px',
                flexWrap: 'wrap',
                position: 'relative'
            }}>

                {/* SKU Dropdown */}
                <div style={{ position: 'relative' }}>
                    <button
                        onClick={() => { setOpenSKU(!openSKU); setOpenProduct(false); setOpenTrans(false); }}
                        style={{
                            background: 'none', border: 'none', fontWeight: 'bold',
                            fontSize: '15px', cursor: 'pointer', padding: '8px 12px',
                            borderRadius: '4px'
                        }}
                    >
                        SKU ▾
                    </button>
                    {openSKU && (
                        <div style={{
                            position: 'absolute', top: '100%', left: 0,
                            backgroundColor: '#fff', border: '1px solid #ccc',
                            borderRadius: '4px', zIndex: 999, minWidth: '160px',
                            boxShadow: '0 4px 12px rgba(0,0,0,0.15)'
                        }}>
                            <div
                                onClick={() => { go('/sku-repo'); setOpenSKU(false); }}
                                style={{ padding: '10px 16px', cursor: 'pointer', fontSize: '14px' }}
                                onMouseEnter={e => e.target.style.backgroundColor = '#f0f0f0'}
                                onMouseLeave={e => e.target.style.backgroundColor = '#fff'}
                            >
                                SKU List
                            </div>
                        </div>
                    )}
                </div>

                {/* Product Dropdown */}
                <div style={{ position: 'relative' }}>
                    <button
                        onClick={() => { setOpenProduct(!openProduct); setOpenSKU(false); setOpenTrans(false); }}
                        style={{
                            background: 'none', border: 'none', fontWeight: 'bold',
                            fontSize: '15px', cursor: 'pointer', padding: '8px 12px',
                            borderRadius: '4px'
                        }}
                    >
                        Product ▾
                    </button>
                    {openProduct && (
                        <div style={{
                            position: 'absolute', top: '100%', left: 0,
                            backgroundColor: '#fff', border: '1px solid #ccc',
                            borderRadius: '4px', zIndex: 999, minWidth: '160px',
                            boxShadow: '0 4px 12px rgba(0,0,0,0.15)'
                        }}>
                            <div
                                onClick={() => { go('/product-repo'); setOpenProduct(false); }}
                                style={{ padding: '10px 16px', cursor: 'pointer', fontSize: '14px' }}
                                onMouseEnter={e => e.target.style.backgroundColor = '#f0f0f0'}
                                onMouseLeave={e => e.target.style.backgroundColor = '#fff'}
                            >
                                Product List
                            </div>
                            <div
                                onClick={() => { go('/product-pie'); setOpenProduct(false); }}
                                style={{ padding: '10px 16px', cursor: 'pointer', fontSize: '14px' }}
                                onMouseEnter={e => e.target.style.backgroundColor = '#f0f0f0'}
                                onMouseLeave={e => e.target.style.backgroundColor = '#fff'}
                            >
                                Product Analysis
                            </div>
                        </div>
                    )}
                </div>

                {/* Transaction Dropdown */}
                <div style={{ position: 'relative' }}>
                    <button
                        onClick={() => { setOpenTrans(!openTrans); setOpenSKU(false); setOpenProduct(false); }}
                        style={{
                            background: 'none', border: 'none', fontWeight: 'bold',
                            fontSize: '15px', cursor: 'pointer', padding: '8px 12px',
                            borderRadius: '4px'
                        }}
                    >
                        Transaction Report ▾
                    </button>
                    {openTrans && (
                        <div style={{
                            position: 'absolute', top: '100%', left: 0,
                            backgroundColor: '#fff', border: '1px solid #ccc',
                            borderRadius: '4px', zIndex: 999, minWidth: '200px',
                            boxShadow: '0 4px 12px rgba(0,0,0,0.15)'
                        }}>
                            <div
                                onClick={() => { go('/transaction-report/OUT'); setOpenTrans(false); }}
                                style={{ padding: '10px 16px', cursor: 'pointer', fontSize: '14px' }}
                                onMouseEnter={e => e.target.style.backgroundColor = '#f0f0f0'}
                                onMouseLeave={e => e.target.style.backgroundColor = '#fff'}
                            >
                                Out Transaction Report
                            </div>
                            <div
                                onClick={() => { go('/transaction-report/IN'); setOpenTrans(false); }}
                                style={{ padding: '10px 16px', cursor: 'pointer', fontSize: '14px' }}
                                onMouseEnter={e => e.target.style.backgroundColor = '#f0f0f0'}
                                onMouseLeave={e => e.target.style.backgroundColor = '#fff'}
                            >
                                In Transaction Report
                            </div>
                        </div>
                    )}
                </div>

                {/* Show User Details */}
                <button
                    onClick={() => go('/login')}
                    style={{
                        background: 'none', border: 'none', fontWeight: 'bold',
                        fontSize: '15px', cursor: 'pointer', padding: '8px 12px',
                        borderRadius: '4px'
                    }}
                >
                    Show User Details
                </button>

                {/* Logout */}
                <button
                    onClick={handleLogout}
                    style={{
                        background: 'none', border: 'none', fontWeight: 'bold',
                        fontSize: '15px', cursor: 'pointer', padding: '8px 12px',
                        borderRadius: '4px'
                    }}
                >
                    Logout
                </button>

            </div>
        </div>
    );
}

export default ManagerMenu;