import './App.css';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import LoginPage from './components/LoginComponent/LoginPage';
import RegisterUser from './components/LoginComponent/RegisterUser';
import AdminMenu from './components/LoginComponent/AdminMenu';
import ManagerMenu from './components/LoginComponent/ManagerMenu';
import VendorMenu from './components/LoginComponent/VendorMenu';  

function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<LoginPage />} />
          <Route path="/register" element={<RegisterUser />} />
          <Route path="/admin-menu" element={<AdminMenu />} />
          <Route path="/manager-menu" element={<ManagerMenu />} />
          <Route path="/vendor-menu" element={<VendorMenu />} /> 
        </Routes>
      </BrowserRouter>

</div>
  );
}

export default App;